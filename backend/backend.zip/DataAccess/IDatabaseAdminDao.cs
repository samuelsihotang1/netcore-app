using backend.Dtos;

namespace backend.DataAccess
{
    public interface IDatabaseAdminDao
    {
        Task<DatabaseResetResultDto> ResetAsync(DatabaseResetRequestDto input, CancellationToken ct = default);
    }
}
